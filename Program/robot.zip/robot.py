from jeremy import Jeremy

jezza = Jeremy()

# Arm Test
jezza.set_angle("a", 180)
jezza.set_angle("g", 40)
jezza.sleep(5)
jezza.set_angle("g", 0)
jezza.sleep(2)
jezza.set_angle("a", 0)
jezza.sleep(5)
jezza.set_angle("g", 40)
