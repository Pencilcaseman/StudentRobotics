Could the following parts be made as strong as possible?
 - axle_left.STL
 - axle_mount_right.STL
 - grabber_arm_left.STL
 - grabber_arm_right.STL
 - right_side_axle.STL <= 100% INFILL IF NECESSARY!!! MUST BE STRONG!!!
 - servo_fitting_attachment.STL <= 100% INFILL IF NECESSARY!!! MUST BE STRONG!!!

Thank you :)
